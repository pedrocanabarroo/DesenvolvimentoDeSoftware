package cadastroalunos;

import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author manto
 */
public class TelaCadastro extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TelaCadastro.class.getName());
    
    private ArrayList<Aluno> listaAlunos = new ArrayList<>();

    private static final String ARQUIVO = "alunos.txt";
    
    public TelaCadastro() {
        configurarJanela();
        criarInterface();
        carregarArquivo();
        atualizarTabela();
    }
    
    private void configurarJanela() {

        setTitle("Cadastro de Alunos");
        setSize(1100, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    private void criarInterface() {

        JPanel painelPrincipal = new JPanel(new BorderLayout(10, 10));
        painelPrincipal.setBorder(
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        );

        // ==========================================================
        // PAINEL DO FORMULÁRIO
        // ==========================================================

        JPanel painelFormulario = new JPanel(new GridBagLayout());

        txtNome = new JTextField(20);
        txtDataNascimento = new JTextField(20);
        txtMatricula = new JTextField(20);
        txtCurso = new JTextField(20);
        txtCPF = new JTextField(20);
        txtEndereco = new JTextField(20);
        txtTelefone = new JTextField(20);

        cbmSexo = new JComboBox<>(
                new String[]{
                    "Feminino",
                    "Masculino",
                    "Outro"
                }
        );

        cbmEstado = new JComboBox<>(
                new String[]{
                    "AC", "AL", "AP", "AM",
                    "BA", "CE", "DF", "ES",
                    "GO", "MA", "MT", "MS",
                    "MG", "PA", "PB", "PR",
                    "PE", "PI", "RJ", "RN",
                    "RS", "RO", "RR", "SC",
                    "SP", "SE", "TO"
                }
        );

        adicionarCampo(
                painelFormulario,
                0,
                "Nome completo:",
                txtNome
        );

        adicionarCampo(
                painelFormulario,
                1,
                "Data nascimento:",
                txtDataNascimento
        );

        adicionarCampo(
                painelFormulario,
                2,
                "Sexo:",
                cbmSexo
        );

        adicionarCampo(
                painelFormulario,
                3,
                "Matrícula:",
                txtMatricula
        );

        adicionarCampo(
                painelFormulario,
                4,
                "Curso:",
                txtCurso
        );

        adicionarCampo(
                painelFormulario,
                5,
                "CPF:",
                txtCPF
        );

        adicionarCampo(
                painelFormulario,
                6,
                "Endereço:",
                txtEndereco
        );

        adicionarCampo(
                painelFormulario,
                7,
                "Estado:",
                cbmEstado
        );

        adicionarCampo(
                painelFormulario,
                8,
                "Telefone:",
                txtTelefone
        );

        // ==========================================================
        // BOTÕES
        // ==========================================================

        btnCadastrar = new JButton("CADASTRAR");
        btnEditar = new JButton("EDITAR");
        btnExcluir = new JButton("EXCLUIR");
        btnLimpar = new JButton("LIMPAR");

        btnEditar.setEnabled(false);

        btnCadastrar.addActionListener(e -> cadastrarAluno());
        btnEditar.addActionListener(e -> editarAluno());
        btnExcluir.addActionListener(e -> excluirAluno());
        btnLimpar.addActionListener(e -> limparCampos());

        JPanel painelBotoes = new JPanel(
                new GridLayout(1, 4, 10, 10)
        );

        painelBotoes.add(btnCadastrar);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnLimpar);

        JPanel painelEsquerdo = new JPanel(new BorderLayout(10, 10));

        painelEsquerdo.add(
                new JLabel("DADOS DO ALUNO"),
                BorderLayout.NORTH
        );

        painelEsquerdo.add(
                painelFormulario,
                BorderLayout.CENTER
        );

        painelEsquerdo.add(
                painelBotoes,
                BorderLayout.SOUTH
        );

        // ==========================================================
        // TABELA
        // ==========================================================

        modeloTabela = new DefaultTableModel(
                new Object[][]{},
                new String[]{
                    "Nome",
                    "Nascimento",
                    "Sexo",
                    "Matrícula",
                    "Curso",
                    "CPF",
                    "Endereço",
                    "Estado",
                    "Telefone"
                }
        ) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblAlunos = new JTable(modeloTabela);

        tblAlunos.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        tblAlunos.getSelectionModel().addListSelectionListener(e -> {

            if (!e.getValueIsAdjusting()) {

                int linha = tblAlunos.getSelectedRow();

                if (linha >= 0) {
                    carregarAlunoParaEdicao(linha);
                }
            }
        });

        JScrollPane scrollTabela = new JScrollPane(tblAlunos);

        painelPrincipal.add(
                painelEsquerdo,
                BorderLayout.WEST
        );

        painelPrincipal.add(
                scrollTabela,
                BorderLayout.CENTER
        );

        add(painelPrincipal);
    }
    
    private void adicionarCampo(
            JPanel painel,
            int linha,
            String texto,
            java.awt.Component componente) {

        GridBagConstraints gbc = new GridBagConstraints();

        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets.set(5, 5, 5, 5);

        gbc.gridx = 0;
        gbc.gridy = linha;
        gbc.weightx = 0;

        painel.add(
                new JLabel(texto),
                gbc
        );

        gbc.gridx = 1;
        gbc.weightx = 1;

        painel.add(
                componente,
                gbc
        );
    }
    
     private void cadastrarAluno() {

        if (!validarCampos()) {
            return;
        }

        int matricula;

        try {

            matricula = Integer.parseInt(
                    txtMatricula.getText().trim()
            );

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "A matrícula deve ser um número.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        // Verifica se a matrícula já existe.
        if (matriculaExiste(matricula, -1)) {

            JOptionPane.showMessageDialog(
                    this,
                    "A matrícula informada já está cadastrada.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        Aluno aluno = criarAlunoDosCampos();

        listaAlunos.add(aluno);

        salvarArquivo();
        atualizarTabela();
        limparCampos();

        JOptionPane.showMessageDialog(
                this,
                "Aluno cadastrado com sucesso!"
        );
    }
     
    private void editarAluno() {

        int linha = tblAlunos.getSelectedRow();

        if (linha == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Selecione um aluno para editar."
            );

            return;
        }

        if (!validarCampos()) {
            return;
        }

        int matricula;

        try {

            matricula = Integer.parseInt(
                    txtMatricula.getText().trim()
            );

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "A matrícula deve ser um número.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        // O -1 permite que a própria matrícula do aluno
        // continue sendo utilizada durante a edição.
        if (matriculaExiste(matricula, linha)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Essa matrícula já pertence a outro aluno.",
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
            );

            return;
        }

        Aluno aluno = listaAlunos.get(linha);

        aluno.setNomeCompleto(
                txtNome.getText().trim()
        );

        aluno.setDataNascimento(
                txtDataNascimento.getText().trim()
        );

        aluno.setSexo(
                cbmSexo.getSelectedItem().toString()
        );

        aluno.setMatricula(matricula);

        aluno.setCurso(
                txtCurso.getText().trim()
        );

        aluno.setCpf(
                txtCPF.getText().trim()
        );

        aluno.setEndereco(
                txtEndereco.getText().trim()
        );

        aluno.setEstado(
                cbmEstado.getSelectedItem().toString()
        );

        aluno.setTelefone(
                txtTelefone.getText().trim()
        );

        salvarArquivo();
        atualizarTabela();
        limparCampos();

        JOptionPane.showMessageDialog(
                this,
                "Aluno alterado com sucesso!"
        );
    }
    
    private void excluirAluno() {

        int linha = tblAlunos.getSelectedRow();

        if (linha == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Selecione um aluno para excluir.",
                    "Atenção",
                    JOptionPane.WARNING_MESSAGE
            );

            return;
        }

        int resposta = JOptionPane.showConfirmDialog(
                this,
                "Deseja realmente excluir este aluno?",
                "Confirmar exclusão",
                JOptionPane.YES_NO_OPTION
        );

        if (resposta == JOptionPane.YES_OPTION) {

            listaAlunos.remove(linha);

            salvarArquivo();
            atualizarTabela();
            limparCampos();

            JOptionPane.showMessageDialog(
                    this,
                    "Aluno excluído com sucesso!"
            );
        }
    }
    
    private Aluno criarAlunoDosCampos() {

        return new Aluno(
                txtNome.getText().trim(),
                txtDataNascimento.getText().trim(),
                cbmSexo.getSelectedItem().toString(),
                Integer.parseInt(txtMatricula.getText().trim()),
                txtCurso.getText().trim(),
                txtCPF.getText().trim(),
                txtEndereco.getText().trim(),
                cbmEstado.getSelectedItem().toString(),
                txtTelefone.getText().trim()
        );
    }
    
    private void carregarAlunoParaEdicao(int linha) {

        if (linha < 0 || linha >= listaAlunos.size()) {
            return;
        }

        Aluno aluno = listaAlunos.get(linha);

        txtNome.setText(
                aluno.getNomeCompleto()
        );

        txtDataNascimento.setText(
                aluno.getDataNascimento()
        );

        cbmSexo.setSelectedItem(
                aluno.getSexo()
        );

        txtMatricula.setText(
                String.valueOf(aluno.getMatricula())
        );

        txtCurso.setText(
                aluno.getCurso()
        );

        txtCPF.setText(
                aluno.getCpf()
        );

        txtEndereco.setText(
                aluno.getEndereco()
        );

        cbmEstado.setSelectedItem(
                aluno.getEstado()
        );

        txtTelefone.setText(
                aluno.getTelefone()
        );

        btnEditar.setEnabled(true);
    }
    
    private void limparCampos() {

        txtNome.setText("");
        txtDataNascimento.setText("");
        txtMatricula.setText("");
        txtCurso.setText("");
        txtCPF.setText("");
        txtEndereco.setText("");
        txtTelefone.setText("");

        cbmSexo.setSelectedIndex(0);
        cbmEstado.setSelectedItem("RS");

        tblAlunos.clearSelection();

        btnEditar.setEnabled(false);

        indiceEdicao = -1;
    }
    
    private boolean validarCampos() {

        if (txtNome.getText().trim().isEmpty()) {

            mostrarErro("Informe o nome completo.");
            txtNome.requestFocus();
            return false;
        }

        if (txtDataNascimento.getText().trim().isEmpty()) {

            mostrarErro("Informe a data de nascimento.");
            txtDataNascimento.requestFocus();
            return false;
        }

        if (!validarData(txtDataNascimento.getText().trim())) {

            mostrarErro(
                    "A data deve estar no formato DD/MM/AAAA."
            );

            txtDataNascimento.requestFocus();
            return false;
        }

        if (txtMatricula.getText().trim().isEmpty()) {

            mostrarErro("Informe a matrícula.");
            txtMatricula.requestFocus();
            return false;
        }

        if (txtCurso.getText().trim().isEmpty()) {

            mostrarErro("Informe o curso.");
            txtCurso.requestFocus();
            return false;
        }

        if (txtCPF.getText().trim().isEmpty()) {

            mostrarErro("Informe o CPF.");
            txtCPF.requestFocus();
            return false;
        }

        if (txtEndereco.getText().trim().isEmpty()) {

            mostrarErro("Informe o endereço completo.");
            txtEndereco.requestFocus();
            return false;
        }

        if (txtTelefone.getText().trim().isEmpty()) {

            mostrarErro("Informe o telefone.");
            txtTelefone.requestFocus();
            return false;
        }

        return true;
    }
    
    private boolean validarData(String data) {

        if (data.length() != 10) {
            return false;
        }

        if (data.charAt(2) != '/'
                || data.charAt(5) != '/') {

            return false;
        }

        try {

            int dia = Integer.parseInt(
                    data.substring(0, 2)
            );

            int mes = Integer.parseInt(
                    data.substring(3, 5)
            );

            int ano = Integer.parseInt(
                    data.substring(6, 10)
            );

            if (mes < 1 || mes > 12) {
                return false;
            }

            if (dia < 1 || dia > 31) {
                return false;
            }

            if (ano < 1900 || ano > 2100) {
                return false;
            }

        } catch (NumberFormatException e) {
            return false;
        }

        return true;
    }
    
    private void mostrarErro(String mensagem) {

        JOptionPane.showMessageDialog(
                this,
                mensagem,
                "Erro",
                JOptionPane.ERROR_MESSAGE
        );
    }
    
    private boolean matriculaExiste(
            int matricula,
            int indiceIgnorar) {

        for (int i = 0; i < listaAlunos.size(); i++) {

            if (i == indiceIgnorar) {
                continue;
            }

            if (listaAlunos.get(i).getMatricula() == matricula) {
                return true;
            }
        }

        return false;
    }
    
    private void atualizarTabela() {

        modeloTabela.setRowCount(0);

        for (Aluno aluno : listaAlunos) {

            modeloTabela.addRow(
                    new Object[]{
                        aluno.getNomeCompleto(),
                        aluno.getDataNascimento(),
                        aluno.getSexo(),
                        aluno.getMatricula(),
                        aluno.getCurso(),
                        aluno.getCpf(),
                        aluno.getEndereco(),
                        aluno.getEstado(),
                        aluno.getTelefone()
                    }
            );
        }
    }
    
    
    private void salvarArquivo() {

        try (FileWriter arquivo = new FileWriter(ARQUIVO)) {

            for (Aluno aluno : listaAlunos) {

                arquivo.write(
                        aluno.getNomeCompleto() + ";"
                        + aluno.getDataNascimento() + ";"
                        + aluno.getSexo() + ";"
                        + aluno.getMatricula() + ";"
                        + aluno.getCurso() + ";"
                        + aluno.getCpf() + ";"
                        + aluno.getEndereco() + ";"
                        + aluno.getEstado() + ";"
                        + aluno.getTelefone()
                        + System.lineSeparator()
                );
            }

        } catch (IOException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Erro ao salvar o arquivo:\n"
                    + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    private void carregarArquivo() {

        File arquivo = new File(ARQUIVO);

        if (!arquivo.exists()) {
            return;
        }

        try (BufferedReader leitor =
                new BufferedReader(new FileReader(arquivo))) {

            String linha;

            while ((linha = leitor.readLine()) != null) {

                if (linha.trim().isEmpty()) {
                    continue;
                }

                String[] dados = linha.split(";", -1);

                // São necessários 9 campos.
                if (dados.length != 9) {
                    continue;
                }

                try {

                    Aluno aluno = new Aluno(
                            dados[0],
                            dados[1],
                            dados[2],
                            Integer.parseInt(dados[3]),
                            dados[4],
                            dados[5],
                            dados[6],
                            dados[7],
                            dados[8]
                    );

                    listaAlunos.add(aluno);

                } catch (NumberFormatException e) {

                    System.out.println(
                            "Matrícula inválida no arquivo: "
                            + linha
                    );
                }
            }

        } catch (IOException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Erro ao carregar o arquivo:\n"
                    + e.getMessage(),
                    "Erro",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        lblNome = new javax.swing.JLabel();
        lblDataNascimento = new javax.swing.JLabel();
        lblSexo = new javax.swing.JLabel();
        lblMatricula = new javax.swing.JLabel();
        lblCurso = new javax.swing.JLabel();
        lblEndereco = new javax.swing.JLabel();
        lblEstado = new javax.swing.JLabel();
        lblTelefone = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        txtDataNascimento = new javax.swing.JTextField();
        txtMatricula = new javax.swing.JTextField();
        txtCurso = new javax.swing.JTextField();
        txtEndereco = new javax.swing.JTextField();
        txtTelefone = new javax.swing.JTextField();
        cbmSexo = new javax.swing.JComboBox<>();
        cbmEstado = new javax.swing.JComboBox<>();
        btnCadastrar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txaAreaAlunos = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtCPF = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblAlunos = new javax.swing.JTable();
        btnExcluir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("CADASTRO DE ALUNOS");

        lblNome.setText("Nome completo: ");

        lblDataNascimento.setText("Data nascimento:");

        lblSexo.setText("Sexo:");

        lblMatricula.setText("Matrícula: ");

        lblCurso.setText("Curso:");

        lblEndereco.setText("Endereço:");

        lblEstado.setText("Estado:");

        lblTelefone.setText("Telefone:");

        txtNome.addActionListener(this::txtNomeActionPerformed);

        txtDataNascimento.addActionListener(this::txtDataNascimentoActionPerformed);

        txtMatricula.addActionListener(this::txtMatriculaActionPerformed);

        txtTelefone.addActionListener(this::txtTelefoneActionPerformed);

        cbmSexo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Feminino", "Masculino", "Outro" }));

        cbmEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO" }));

        btnCadastrar.setText("CADASTRAR");
        btnCadastrar.addActionListener(this::btnCadastrarActionPerformed);

        txaAreaAlunos.setColumns(20);
        txaAreaAlunos.setRows(5);
        jScrollPane1.setViewportView(txaAreaAlunos);

        jLabel10.setText("ALUNOS CADASTRADOS");

        jLabel2.setText("CPF");

        tblAlunos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome completo", "Data nascimento", "Sexo", "Matrícula", "Curso", "Endereço", "Estado", "Telefone", "CPF"
            }
        ));
        jScrollPane2.setViewportView(tblAlunos);

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(this::btnExcluirActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(157, 157, 157)
                                    .addComponent(btnCadastrar)
                                    .addGap(61, 61, 61))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(61, 61, 61))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                        .addComponent(lblNome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(lblDataNascimento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(lblSexo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(lblMatricula, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(lblCurso, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(lblEndereco, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(lblEstado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(lblTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGap(18, 18, 18)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(cbmSexo, 0, 158, Short.MAX_VALUE)
                                                    .addComponent(cbmEstado, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(txtNome)
                                                    .addComponent(txtDataNascimento)
                                                    .addComponent(txtMatricula)
                                                    .addComponent(txtCurso)
                                                    .addComponent(txtEndereco)
                                                    .addComponent(txtTelefone)
                                                    .addComponent(txtCPF)))))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(101, 101, 101)
                                .addComponent(jLabel1)))
                        .addGap(31, 31, 31)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 759, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(232, 232, 232)
                        .addComponent(btnExcluir)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblNome)
                            .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblDataNascimento)
                            .addComponent(txtDataNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblSexo, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbmSexo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblMatricula)
                            .addComponent(txtMatricula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblCurso)
                            .addComponent(txtCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblEndereco)
                            .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblEstado)
                            .addComponent(cbmEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTelefone)
                            .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCadastrar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 422, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnExcluir)
                .addContainerGap(410, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        
        if(txtEndereco.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Preencha o endereço");
            return;
        }
        
        String endereco = txtEndereco.getText();
        String [ ] partes = endereco.split(", ");
        
        if(partes.length != 5){
            JOptionPane.showMessageDialog(this, "Informe o endereço completo");
            return;
        }
        
        
        if(txaAreaAlunos.getText().contains(txtMatricula.getText())){
            JOptionPane.showMessageDialog(this, "Matricula já cadastrada");
            return;
        }
        
        int matricula = Integer.parseInt(txtMatricula.getText());
        
        String data = txtDataNascimento.getText();
        if(data.length()!= 10 || data.charAt(2) != '/' || data.charAt(5) != '/'){
            JOptionPane.showMessageDialog(this, "A data deve estar no formato DD/MM/AAAA");
            return;
        }
        
        
        
        Aluno aluno = new Aluno(
            txtNome.getText(),
            txtDataNascimento.getText(),
            cbmSexo.getSelectedItem().toString(),
            Integer.parseInt(txtMatricula.getText()),
            txtCurso.getText(),
            txtCPF.getText(),
            txtEndereco.getText(),
            cbmEstado.getSelectedItem().toString(),
            txtTelefone.getText()
        );
        
        listaAlunos.add(aluno);
        salvarArquivo();
        
        DefaultTableModel modelo = (DefaultTableModel) tblAlunos.getModel();
        
        modelo.addRow(new Object[]{
            aluno.getNomeCompleto(),
            aluno.getDataNascimento(),
            aluno.getSexo(),
            aluno.getMatricula(),
            aluno.getCurso(),
            aluno.getEndereco(),
            aluno.getEstado(),
            aluno.getTelefone(),
            aluno.getCpf()
        });

        txaAreaAlunos.append(
        aluno.getNomeCompleto() + ";" +
        aluno.getDataNascimento() + ";" +
        aluno.getSexo() + ";" +
        aluno.getMatricula() + ";" +
        aluno.getCurso() + ";" +
        aluno.getEndereco() + ";" +
        aluno.getEstado() + ";" +
        aluno.getTelefone() + "\n" +
        aluno.getCpf() + ";"        
    );
        
        txtNome.setText("");
        txtDataNascimento.setText("");
        txtMatricula.setText("");
        txtCurso.setText("");
        txtEndereco.setText("");
        txtTelefone.setText("");
        txtCPF.setText("");
        cbmSexo.setSelectedIndex(0);
        cbmEstado.setSelectedIndex(0);
        
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeActionPerformed

    private void txtDataNascimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDataNascimentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDataNascimentoActionPerformed

    private void txtTelefoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefoneActionPerformed

    private void txtMatriculaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMatriculaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMatriculaActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        int linha = tblAlunos.getSelectedRow();
        FileWriter arquivo;
        if(linha == -1){
            JOptionPane.showMessageDialog(
                    null,
                    "Selecione um aluno na tabela.",
                    "Atenção",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(
                null,
                "Deseja realmente excluir esta pessoa?",
                "Confirmação",
                JOptionPane.YES_NO_CANCEL_OPTION
        );
        if(resposta == JOptionPane.YES_OPTION){
            listaAlunos.remove(linha);        
            salvarArquivo();
            DefaultTableModel tabela = (DefaultTableModel) tblAlunos.getModel();
            
            tabela.removeRow(linha);
            
            System.out.println("Pessoa excluída!");
        }
    }//GEN-LAST:event_btnExcluirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
      //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new TelaCadastro().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JComboBox<String> cbmEstado;
    private javax.swing.JComboBox<String> cbmSexo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblCurso;
    private javax.swing.JLabel lblDataNascimento;
    private javax.swing.JLabel lblEndereco;
    private javax.swing.JLabel lblEstado;
    private javax.swing.JLabel lblMatricula;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblSexo;
    private javax.swing.JLabel lblTelefone;
    private javax.swing.JTable tblAlunos;
    private javax.swing.JTextArea txaAreaAlunos;
    private javax.swing.JTextField txtCPF;
    private javax.swing.JTextField txtCurso;
    private javax.swing.JTextField txtDataNascimento;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtMatricula;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtTelefone;
    // End of variables declaration//GEN-END:variables
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.table.DefaultTableModel modeloTabela;
    private int indiceEdicao = -1;
}
