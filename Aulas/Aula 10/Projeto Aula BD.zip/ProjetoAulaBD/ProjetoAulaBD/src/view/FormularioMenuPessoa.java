/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

public class FormularioMenuPessoa extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FormularioMenuPessoa.class.getName());

    public FormularioMenuPessoa() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MenuBarOpcao = new javax.swing.JMenuBar();
        MenuArquivo = new javax.swing.JMenu();
        Sair = new javax.swing.JMenuItem();
        MenuCadastro = new javax.swing.JMenu();
        MenuItemCadastro = new javax.swing.JMenuItem();
        menu_Editar = new javax.swing.JMenuItem();
        MenuRelatorio = new javax.swing.JMenu();
        menu_Relatorio = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        MenuArquivo.setText("Arquivo");

        Sair.setText("Sair");
        Sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SairActionPerformed(evt);
            }
        });
        MenuArquivo.add(Sair);

        MenuBarOpcao.add(MenuArquivo);

        MenuCadastro.setText("Cadastro");

        MenuItemCadastro.setText("Cadastro Pessoas");
        MenuItemCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuItemCadastroActionPerformed(evt);
            }
        });
        MenuCadastro.add(MenuItemCadastro);

        menu_Editar.setText("Editar e excluir Pessoas");
        menu_Editar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_EditarActionPerformed(evt);
            }
        });
        MenuCadastro.add(menu_Editar);

        MenuBarOpcao.add(MenuCadastro);

        MenuRelatorio.setText("Relatório");

        menu_Relatorio.setText("Relatório de Pessoas");
        menu_Relatorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_RelatorioActionPerformed(evt);
            }
        });
        MenuRelatorio.add(menu_Relatorio);

        MenuBarOpcao.add(MenuRelatorio);

        setJMenuBar(MenuBarOpcao);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 277, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MenuItemCadastroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuItemCadastroActionPerformed
        FormularioCadastroPessoa cadPessoa = new FormularioCadastroPessoa();
        cadPessoa.setVisible(true);
    }//GEN-LAST:event_MenuItemCadastroActionPerformed

    private void menu_RelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_RelatorioActionPerformed
        FormularioRelatorioPessoa relPessoa = new FormularioRelatorioPessoa();
        relPessoa.setVisible(true);
    }//GEN-LAST:event_menu_RelatorioActionPerformed

    private void menu_EditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_EditarActionPerformed
        FormularioEditarExcluirPessoa consPessoa = new FormularioEditarExcluirPessoa();
        consPessoa.setVisible(true);
    }//GEN-LAST:event_menu_EditarActionPerformed

    private void SairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SairActionPerformed
        System.exit(0);
    }//GEN-LAST:event_SairActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new FormularioMenuPessoa().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu MenuArquivo;
    private javax.swing.JMenuBar MenuBarOpcao;
    private javax.swing.JMenu MenuCadastro;
    private javax.swing.JMenuItem MenuItemCadastro;
    private javax.swing.JMenu MenuRelatorio;
    private javax.swing.JMenuItem Sair;
    private javax.swing.JMenuItem menu_Editar;
    private javax.swing.JMenuItem menu_Relatorio;
    // End of variables declaration//GEN-END:variables
}
