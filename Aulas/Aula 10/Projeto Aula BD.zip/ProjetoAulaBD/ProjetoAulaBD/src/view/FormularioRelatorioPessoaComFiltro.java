package view;

import beans.Pessoa;
import dao.PessoaDao;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class FormularioRelatorioPessoaComFiltro extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FormularioRelatorioPessoaComFiltro.class.getName());

    public FormularioRelatorioPessoaComFiltro() {
        initComponents();
        preencheTabela();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnGrp_Sexo = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblPessoas = new javax.swing.JTable();
        lblTitulo1 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        rdo_Masculino = new javax.swing.JRadioButton();
        rdo_Feminino = new javax.swing.JRadioButton();
        btn_Limpar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        tblPessoas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome", "Sexo", "Idioma"
            }
        ));
        jScrollPane1.setViewportView(tblPessoas);

        lblTitulo1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTitulo1.setText("Relatório de Pessoas");

        txtNome.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txtNomeCaretUpdate(evt);
            }
        });
        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });

        jLabel1.setText("Nome:");

        jLabel2.setText("Sexo:");

        btnGrp_Sexo.add(rdo_Masculino);
        rdo_Masculino.setText("Masculino");
        rdo_Masculino.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                rdo_MasculinoStateChanged(evt);
            }
        });
        rdo_Masculino.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdo_MasculinoActionPerformed(evt);
            }
        });

        btnGrp_Sexo.add(rdo_Feminino);
        rdo_Feminino.setText("Feminino");
        rdo_Feminino.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                rdo_FemininoStateChanged(evt);
            }
        });

        btn_Limpar.setText("Limpar");
        btn_Limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LimparActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 398, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblTitulo1)
                .addGap(84, 84, 84))
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(rdo_Masculino)
                .addGap(27, 27, 27)
                .addComponent(rdo_Feminino)
                .addGap(29, 29, 29)
                .addComponent(btn_Limpar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(lblTitulo1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(rdo_Masculino)
                    .addComponent(rdo_Feminino)
                    .addComponent(btn_Limpar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 276, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeActionPerformed

    private void txtNomeCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txtNomeCaretUpdate
        preencheTabela();
    }//GEN-LAST:event_txtNomeCaretUpdate

    private void rdo_MasculinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdo_MasculinoActionPerformed
        preencheTabela();
    }//GEN-LAST:event_rdo_MasculinoActionPerformed

    private void rdo_MasculinoStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_rdo_MasculinoStateChanged
        preencheTabela();
    }//GEN-LAST:event_rdo_MasculinoStateChanged

    private void rdo_FemininoStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_rdo_FemininoStateChanged
        preencheTabela();
    }//GEN-LAST:event_rdo_FemininoStateChanged

    private void btn_LimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LimparActionPerformed
        txtNome.setText("");
        btnGrp_Sexo.clearSelection();
    }//GEN-LAST:event_btn_LimparActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new FormularioRelatorioPessoaComFiltro().setVisible(true));
    }

    public void preencheTabela() {
        String sexo = "";
        PessoaDao pDAO = new PessoaDao();
        
        if (rdo_Masculino.isSelected())
            sexo = "M";
        else if (rdo_Feminino.isSelected())
            sexo = "F";
        else
            sexo = "";
        
        List<Pessoa> listaPessoas = pDAO.getPessoas(txtNome.getText(),sexo);
        DefaultTableModel tabelaPessoas = (DefaultTableModel) tblPessoas.getModel();
        
        tabelaPessoas.setNumRows(0);
        
        for(Pessoa p : listaPessoas) {
            Object[] obj = new Object[] {
                p.getId(),
                p.getNome(),
                p.getSexo(),
                p.getIdioma()
            };
        tabelaPessoas.addRow(obj);
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup btnGrp_Sexo;
    private javax.swing.JButton btn_Limpar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblTitulo1;
    private javax.swing.JRadioButton rdo_Feminino;
    private javax.swing.JRadioButton rdo_Masculino;
    private javax.swing.JTable tblPessoas;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
